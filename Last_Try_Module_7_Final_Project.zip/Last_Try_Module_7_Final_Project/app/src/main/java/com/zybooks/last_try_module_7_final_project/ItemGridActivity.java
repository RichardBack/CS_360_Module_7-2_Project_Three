package com.zybooks.last_try_module_7_final_project;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import com.zybooks.last_try_module_7_final_project.R;

public class ItemGridActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_grid);

        recyclerView = findViewById(R.id.recycler_view);

        DataBaseHelper dbHelper = new DataBaseHelper(this);
        db = dbHelper.getReadableDatabase();

        List<Item> itemList = fetchItemsFromDatabase();

        itemAdapter = new ItemAdapter(itemList);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setAdapter(itemAdapter);
    }

    private List<Item> fetchItemsFromDatabase() {
        List<Item> itemList = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM " + DataBaseHelper.TABLE_ITEMS, null);

        int itemNameIndex = cursor.getColumnIndex(DataBaseHelper.COLUMN_ITEM_NAME);
        int quantityIndex = cursor.getColumnIndex(DataBaseHelper.COLUMN_QUANTITY);

        while (cursor.moveToNext()) {
            String itemName = cursor.getString(itemNameIndex);
            int quantity = cursor.getInt(quantityIndex);
            itemList.add(new Item(itemName, quantity));

        }

        cursor.close();
        return itemList;
    }
}
