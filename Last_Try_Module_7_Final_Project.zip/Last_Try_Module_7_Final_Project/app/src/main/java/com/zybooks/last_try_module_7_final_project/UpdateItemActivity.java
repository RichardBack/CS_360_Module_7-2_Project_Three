package com.zybooks.last_try_module_7_final_project;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.List;

public class UpdateItemActivity extends AppCompatActivity {
    private Spinner itemSpinner;
    private EditText newValueEditText;
    private Button updateButton;

    private static final int SMS_PERMISSION_REQUEST_CODE = 123; // Define your permission code here

    private DataBaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_item);

        itemSpinner = findViewById(R.id.spinner_item);
        newValueEditText = findViewById(R.id.edit_new_value);
        updateButton = findViewById(R.id.button_update);

        dbHelper = new DataBaseHelper(this);

        List<String> itemNames = dbHelper.fetchItemNames();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, itemNames);
        itemSpinner.setAdapter(adapter);

        updateButton.setOnClickListener(view -> updateItemValue());
    }

    private void updateItemValue() {
        String selectedItem = itemSpinner.getSelectedItem().toString();
        String newValue = newValueEditText.getText().toString();

        int updatedRows = dbHelper.updateItem(selectedItem, newValue);
        if (updatedRows > 0) {
            Toast.makeText(this, "Item value updated successfully", Toast.LENGTH_SHORT).show();

            // Check for SMS permission and send SMS alerts
            } else {
            Toast.makeText(this, "Item value update failed", Toast.LENGTH_SHORT).show();
        }
    }
}
