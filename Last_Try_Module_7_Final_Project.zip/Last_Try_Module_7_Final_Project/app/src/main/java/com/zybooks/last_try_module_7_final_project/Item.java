package com.zybooks.last_try_module_7_final_project;

public class Item {
    private String itemName;
    private int quantity;

    public Item(String itemName, int quantity) {
        this.itemName = itemName;
        this.quantity = quantity;
    }
    // Create getter and setter methods if necessary
    public String getItemName() {
        return itemName;
    }

    public int getQuantity() {
        return quantity;
    }
}

