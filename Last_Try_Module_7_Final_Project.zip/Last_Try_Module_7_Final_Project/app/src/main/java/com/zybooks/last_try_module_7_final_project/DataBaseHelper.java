package com.zybooks.last_try_module_7_final_project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "myapp.db";
    private static final int DATABASE_VERSION = 1;

    // Include column and table names for users
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Include column and table names for items
    public static final String TABLE_ITEMS = "items";
    public static final String COLUMN_ITEM_ID = "_id";
    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_QUANTITY = "quantity";

    // Create a default constructor
    public DataBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String createUsersTableQuery = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT NOT NULL, " +
                COLUMN_PASSWORD + " TEXT NOT NULL)";
        db.execSQL(createUsersTableQuery);

        // Create items table
        String createItemsTableQuery = "CREATE TABLE " + TABLE_ITEMS + " (" +
                COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ITEM_NAME + " TEXT NOT NULL, " +
                COLUMN_QUANTITY + " INTEGER)";
        db.execSQL(createItemsTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Database upgrades
        if (oldVersion < newVersion) {
            // Drop and recreate tables, or perform necessary migrations
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
            onCreate(db);
        }
    }

    public long createItem(String itemName, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName);
        values.put(COLUMN_QUANTITY, quantity);

        long newRowId = db.insert(TABLE_ITEMS, null, values);
        db.close();

        return newRowId;
    }

    public int updateItem(String itemName, String newValue) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_QUANTITY, newValue);

        String whereClause = COLUMN_ITEM_NAME + " = ?";
        String[] whereArgs = {itemName};

        int updatedRows = db.update(TABLE_ITEMS, values, whereClause, whereArgs);
        db.close();

        return updatedRows;
    }

    public List<String> fetchItemNames() {
        List<String> itemNames = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ITEMS, new String[]{COLUMN_ITEM_NAME}, null, null, null, null, null);

        int columnIndex = cursor.getColumnIndex(COLUMN_ITEM_NAME);

        while (cursor.moveToNext()) {
            String itemName = cursor.getString(columnIndex);
            itemNames.add(itemName);
        }

        cursor.close();
        db.close();
        return itemNames;
    }

    // Apply user authentication
    public boolean authenticateUser() {
        // Authentication logic goes here
        return false;
    }

    // Apply item deletion
    public int deleteItem(long itemId) {
        SQLiteDatabase db = this.getWritableDatabase();

        String whereClause = COLUMN_ITEM_ID + " = ?";
        String[] whereArgs = {String.valueOf(itemId)};

        int deletedRows = db.delete(TABLE_ITEMS, whereClause, whereArgs);
        db.close();

        return deletedRows;
    }
}


